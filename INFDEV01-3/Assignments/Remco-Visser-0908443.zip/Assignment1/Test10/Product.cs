﻿using System;

namespace AssignmentComplete
{
	public class Product
	{
		public Product ()
		{
		}
	}
}

